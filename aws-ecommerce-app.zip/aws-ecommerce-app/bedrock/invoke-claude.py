"""
Amazon Bedrock - Claude API Integration
Generates AI-powered product summaries for the e-commerce application.
Uses EC2 IAM role — no hardcoded credentials required.
"""

import boto3
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Credentials automatically loaded from EC2 IAM role
bedrock = boto3.client(
    service_name="bedrock-runtime",
    region_name="us-east-1"
)

MODEL_ID = "anthropic.claude-3-sonnet-20240229-v1:0"


def generate_product_summary(product_name: str, features: list, price: float) -> str:
    """
    Generates a product summary using Amazon Bedrock Claude API.

    Args:
        product_name: Name of the product
        features: List of product features
        price: Product price in INR

    Returns:
        AI-generated product summary string
    """
    prompt = f"""You are a product copywriter for an e-commerce store.
Write a compelling 2-3 sentence product summary for the following product.
Keep it concise, highlight key benefits, and end with a call to action.

Product: {product_name}
Features: {', '.join(features)}
Price: Rs.{price:,.2f}

Write only the product summary, nothing else."""

    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 200,
        "messages": [{"role": "user", "content": prompt}]
    }

    try:
        response = bedrock.invoke_model(
            modelId=MODEL_ID,
            body=json.dumps(request_body),
            contentType="application/json",
            accept="application/json"
        )
        response_body = json.loads(response["body"].read())
        summary = response_body["content"][0]["text"]
        logger.info(f"Summary generated for: {product_name}")
        return summary

    except Exception as e:
        logger.error(f"Error invoking Bedrock: {e}")
        raise


def generate_bulk_summaries(products: list) -> list:
    """Generates summaries for a list of products."""
    results = []
    for product in products:
        try:
            summary = generate_product_summary(
                product_name=product["name"],
                features=product["features"],
                price=product["price"]
            )
            product["summary"] = summary
        except Exception as e:
            logger.error(f"Failed for {product['name']}: {e}")
            product["summary"] = "Summary unavailable"
        results.append(product)
    return results


# Example usage
if __name__ == "__main__":
    sample_products = [
        {
            "name": "Wireless Bluetooth Headphones",
            "features": ["40hr battery", "Active Noise Cancellation", "Foldable design"],
            "price": 2999.00
        },
        {
            "name": "Mechanical Gaming Keyboard",
            "features": ["RGB backlight", "Cherry MX switches", "Anti-ghosting"],
            "price": 4499.00
        }
    ]

    print("Generating product summaries using Amazon Bedrock Claude...\n")
    products = generate_bulk_summaries(sample_products)

    for p in products:
        print(f"Product : {p['name']}")
        print(f"Summary : {p['summary']}")
        print("-" * 60)
