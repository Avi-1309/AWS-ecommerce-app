#!/bin/bash
# S3 Lifecycle Policy — transitions objects to S3-IA after 30 days
BUCKET_NAME="ecommerce-product-images"

aws s3api put-bucket-lifecycle-configuration \
  --bucket $BUCKET_NAME \
  --lifecycle-configuration '{
    "Rules": [
      {
        "ID": "TransitionToIA",
        "Status": "Enabled",
        "Filter": { "Prefix": "products/" },
        "Transitions": [{ "Days": 30, "StorageClass": "STANDARD_IA" }]
      },
      {
        "ID": "ExpireBackups",
        "Status": "Enabled",
        "Filter": { "Prefix": "db-backups/" },
        "Expiration": { "Days": 90 }
      }
    ]
  }'

echo "Lifecycle policy applied to $BUCKET_NAME"
